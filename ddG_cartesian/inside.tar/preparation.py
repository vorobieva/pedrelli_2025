import sys
import argparse
import os
import os.path as osp

f_r = open('params.txt', 'r')
f_w = open('params.py', 'w')

for line in f_r.readlines():
    f_w.write(line + "\n")

f_r.close()
f_w.close()
import time
time.sleep(5)
try:
    # from params import * 
    import params as prm
except:
    sys.exit(1) 


if len(prm.pdb_name) > 0:
    check = os.path.isfile(prm.pdb_name)
    if not check:
        sys.exit(2)
else:
    sys.exit(3)


if len(prm.name_relax_xml) > 0:
    check = os.path.isfile(prm.name_relax_xml)
    if not check:
        sys.exit(4)
    if check:
        os.rename(f'{prm.name_relax_xml} tmp/relax_coordinate_cst.xml')



if not os.path.exists('tmp'):
    os.mkdir('tmp')
os.chdir('tmp')

path_to_Rosetta = str(prm.path_to_Rosetta_main)
pdb_name = prm.pdb_name[:-4]
os.system(f'''grep "^ATOM" ../{pdb_name}.pdb > {pdb_name}_clean.pdb''')

with open("task.list", "w") as task_list:
    for i in range(1, prm.ntraj + 1):
        task_list.write(str(i)+"\n")
        if not os.path.exists(str(i)):
            os.mkdir(str(i))

beginning = '''#!/usr/bin/env bash
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 1
#SBATCH --mem 4096
#SBATCH --time 72:00:00
#SBATCH --array '''

with open("cmd.jobs", "w") as relax_jobs:
    relax_jobs.write(beginning + "[1-" + str(prm.ntraj) + "]")
    if prm.ntraj > prm.sbatch_array_length:
        relax_jobs.write("%" + str(prm.sbatch_array_length))

    relax_jobs.write('''\n\nLINE=$(sed -n "$SLURM_ARRAY_TASK_ID"p task.list)\n\n''')
    rosetta_script = osp.join(path_to_Rosetta, 'source/bin/rosetta_scripts.default.linuxgccrelease')
    relax_jobs.write(f'''cd $LINE && {rosetta_script} -s ../''')
    relax_jobs.write(pdb_name + f'_clean.pdb  -parser:protocol ../relax_coordinate_cst.xml -nstruct {prm.nstruct} > stdout.txt')


beginning = '''#!/usr/bin/env bash
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 1
#SBATCH --mem 4096
#SBATCH --time 72:00:00\n\n'''

with open("scoring.jobs", "w") as scoring_jobs:
    scoring_jobs.write(beginning)
    scoring_jobs.write('''module load Python/3.11.3-GCCcore-12.3.0 \n''')
    scoring_jobs.write('''module load  SciPy-bundle/2023.07-gfbf-2023a \n''')
    scoring_jobs.write('''python get_scores.py''')

if not os.path.exists('mutations'):
    os.mkdir('mutations')
os.chdir('mutations')


mutations = []

for aa in range(0, len(prm.mut)):
	pos = prm.mut[aa]
	AA = prm.mut[aa][0]
	if not os.path.exists(pos):
		os.makedirs(pos)
	for m in prm.aa_list:
		if m != AA:
			mutation = pos+m
			mutations.append(mutation)
			if not os.path.exists(pos+"/"+mutation):
				os.makedirs(pos+"/"+mutation)
			with open(pos+"/"+mutation+"/mutfile",'w') as mut_file:
				mut_file.write("total 1\n")
				mut_file.write("1\n")
				mut_file.write("%s %d %s\n" %(AA, int(prm.mut[aa][1:]), m))
count = 0
with open("task.list", "w") as task_list:
	for i in mutations:
		task_list.write(i+"\n")
		count += 1

beginning = '''#!/usr/bin/env bash
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 1
#SBATCH --mem 4096
#SBATCH --time 48:00:00
#SBATCH --array '''

with open("cmd_ddg.jobs", "w") as ddg_jobs:
    ddg_jobs.write(beginning + "[1-" + str(count) + "]")
    if count > prm.sbatch_array_length:
        ddg_jobs.write("%" + str(prm.sbatch_array_length))

    rosetta_script_ddg = osp.join(path_to_Rosetta, 'source/bin/cartesian_ddg.default.linuxgccrelease')

    ddg_jobs.write('''\n\nLINE=$(sed -n "$SLURM_ARRAY_TASK_ID"p task.list)\n\n''')
    ddg_jobs.write('''cd ${LINE::-1}/${LINE} && ''')
    ddg_jobs.write(f'''{rosetta_script_ddg} -s ../../''')

    database_path = osp.join(path_to_Rosetta, 'database')
    
    ddg_jobs.write('relaxed_' + pdb_name + f'_clean*.pdb  -database {database_path} -ddg:mut_file mutfile -ddg:iterations ' + str(prm.ddg_iterations) + ' ')
    ddg_jobs.write('''-force_iterations ''' + str(prm.force_iterations).lower() + ''' -ddg::score_cutoff ''' + str(prm.ddg_score_cutoff) + ''' -ddg::cartesian ''')
    ddg_jobs.write('''-ddg::dump_pdbs ''' + str(prm.ddg_dump_pdbs).lower() + ''' -ddg:bbnbrs ''' + str(prm.ddg_bbnbrs) + ''' -fa_max_dis  ''' + str(prm.fa_max_dis))
    ddg_jobs.write(''' -score:weights ''' + str(prm.score_weights) + ''' > stdout.txt''')


beginning = '''#!/usr/bin/env bash
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 1
#SBATCH --mem 4096
#SBATCH --time 72:00:00\n'''

with open("analyze.jobs", "w") as analyze_jobs:
    analyze_jobs.write(beginning)
    if len(prm.email) > 0:
        analyze_jobs.write('''\n#SBATCH --mail-user=''')
        analyze_jobs.write(prm.email + "\n")
        analyze_jobs.write('''#SBATCH --mail-type=END\n''')

    analyze_jobs.write('''module load Python/3.11.3-GCCcore-12.3.0 \n''')
    analyze_jobs.write('''module load  SciPy-bundle/2023.07-gfbf-2023a \n''')
    analyze_jobs.write('''python analyze_ssm.py''')
