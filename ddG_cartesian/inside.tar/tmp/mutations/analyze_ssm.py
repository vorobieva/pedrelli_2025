import os
import glob
import numpy as np
from params import mut, pdb_name
from params import aa_list as tmp

def nice_order(aa_l):
    nice_order_for_heatmap  = ["G","P","E","D","R","K","H","Q","N","T","S","Y","W","F","M","C","I","L","V","A"]
    aa_list_for_an = nice_order_for_heatmap.copy()
    for item in nice_order_for_heatmap:
        if item not in aa_l:
            aa_list_for_an.remove(item)
    return aa_list_for_an
aa_list = nice_order(tmp)

ala_scan = {}
ssm = np.zeros([len(aa_list), len(mut)], dtype=float)


pdb_name = 'relaxed_' + pdb_name[:-4] + '_clean'

for aa in range(0, len(mut)):
	pos = mut[aa]
	AA = mut[aa][0]
	if AA != "A":
		with open(pos+"/"+pos+"A/mutfile.ddg", 'r') as mutfile:
			n_WT = 0
			n_MUT = 0
			score_WT = 0
			score_MUT = 0
			for line in mutfile:
				if "WT" in line:
					score = float(line.split()[3])
					n_WT += 1
					score_WT += score
				elif "MUT_" in line:
					score = float(line.split()[3])
					n_MUT += 1
					score_MUT += score
			score_WT = score_WT/n_WT
			score_MUT = score_MUT/n_MUT
			ddG = score_MUT - score_WT
			ala_scan[mut[aa][1:]] = ddG
	else:
		ddG = 0
		ala_scan[mut[aa][1:]] = ddG

	for i in range(0, len(aa_list)):
		amino_acid = aa_list[i]
		if AA != amino_acid:
			mutation = mut[aa]+amino_acid
			n_WT = 0
			n_MUT = 0
			score_WT = 0
			score_MUT = 0
			with open(pos+"/"+mutation+"/mutfile.ddg", 'r') as mutfile:
				for line in mutfile:
					if "WT" in line:
						score = float(line.split()[3])
						n_WT += 1
						score_WT += score
					elif "MUT_" in line:
						score = float(line.split()[3])
						n_MUT += 1
						score_MUT += score
			score_WT = score_WT/n_WT
			score_MUT = score_MUT/n_MUT
			ddG = score_MUT - score_WT
			ssm[i,aa] = float(ddG)
print(ssm)
print(ala_scan)

np.savetxt("../../SSM_ddg.csv", ssm, delimiter=",")
