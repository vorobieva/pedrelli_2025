import pandas as pd
import numpy as np
import glob
import os
import re
from shutil import copyfile
from collections import Counter
import subprocess


dall_scores = pd.DataFrame()
for f in glob.glob('*/score.sc'):
	pth = str(f).split('/')[0]
	tmp = pd.read_csv(f, sep='\s+', header=1);
	tmp['description'] = pth + '/' + tmp['description']
	dall_scores = pd.concat([dall_scores, tmp], ignore_index = True)


dres = dall_scores[dall_scores.total_score == dall_scores.total_score.min()]
source  = list(dres.description)[0] + '.pdb'
pdb = source.split('/')[1]
target = "mutations/relaxed_"  + pdb
os.system(f'cp {source} {target}')




